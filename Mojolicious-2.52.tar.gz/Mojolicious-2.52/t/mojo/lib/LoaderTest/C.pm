package LoaderTest::C;

# "We started out like Romeo and Juliet, but it ended up in tragedy."
use Mojo::Base -base;

1;
