package LoaderTest::B;

# "The Internet King? I wonder if he could provide faster nudity..."
use Mojo::Base -base;

1;
