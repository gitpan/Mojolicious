package LoaderTest::A;

# "I have purchased the Springfield YMCA.
#  I plan to tear it down and turn the land into a nature preserve.
#  There, I will hunt the deadliest game of all... man!"
use Mojo::Base -base;

1;
