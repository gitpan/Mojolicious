package LoaderException;

use Mojo::Base -base;

# "No offence Apu, but when they’re handing out religions you must be out
#  taking a whizz."

foo {

1;
