package BaseTest::Base3;
use BaseTest::Base1 -base;

# "I've done everything the Bible says,
#  even the stuff that contradicts the other stuff!"
has 'evil';

1;
