package BaseTest::Base1;
use Mojo::Base -base;

# "Okay folks, show's over. Nothing to see here, show's... Oh my god!
#  A horrible plane crash!
#  Hey everybody, get a load of this flaming wreckage!
#  Come on, crowd around, crowd around!"
has 'bananas';

1;
