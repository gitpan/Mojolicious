package MojoliciousTest::Foo::Bar;
use Mojolicious::Controller -base;

# "Poor Bender. Without his brain he's become all quiet and helpful."
sub index {1}

1;
