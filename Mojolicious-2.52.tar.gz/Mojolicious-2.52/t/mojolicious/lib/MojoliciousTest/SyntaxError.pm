package MojoliciousTest::SyntaxError;
use Mojo::Base 'Mojolicious::Controller';

# "In the future... people will live twice as long,
#  computers will die twice as fast."
sub foo {

1;
